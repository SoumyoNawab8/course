This app has been made by using React.Js and using MobX.

The structure of the data had been made by using JSON.